<?php declare(strict_types=1);
/**
 * Uthando CMS (http://www.shaunfreeman.co.uk/)
 *
 * @package   User\Controller
 * @author    Shaun Freeman <shaun@shaunfreeman.co.uk>
 * @copyright Copyright (c) 2018 Shaun Freeman. (http://www.shaunfreeman.co.uk)
 * @license   see LICENSE
 */

namespace User\Controller;


use DoctrineModule\Authentication\Adapter\ObjectRepository;
use Zend\Authentication\AuthenticationService;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

class AuthController extends AbstractActionController
{
    /**
     * @var AuthenticationService
     */
    protected $authService;

    public function __construct($authService)
    {
        $this->authService = $authService;
    }

    public function loginAction()
    {
        $data = $this->getRequest()->getPost();

        // If you used another name for the authentication service, change it here
        $authService = $this->authService;

        /** @var ObjectRepository $adapter */
        $adapter = $authService->getAdapter();
        $adapter->setIdentity('shaun@shaunfreeman.name');
        $adapter->setCredential('gr82BeAd?');
        $authResult = $authService->authenticate();

        $authService->getStorage()->write($authResult->getIdentity());

        if ($authResult->isValid()) {
            $status = 'Your authentication credentials are valid';
        } else {
            $status = 'Your authentication credentials are not valid';
        }

        return new ViewModel([
            'status' => $status,
        ]);
    }

    public function logoutAction()
    {
        $this->authManager->logout();
        return $this->redirect()->toRoute('login');
    }
}