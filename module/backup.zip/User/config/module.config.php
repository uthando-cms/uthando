<?php

namespace User;

use Doctrine\ORM\EntityManager;
use Doctrine\ORM\Mapping\Driver\AnnotationDriver;
use User\Controller\AuthController;
use User\Controller\UserAdminController;
use User\Controller\UserController;
use User\Entity\UserEntity;
use User\Service\AuthenticationManager;
use User\Service\Factory\AuthenticationManagerFactory;
use User\Service\Factory\UserManagerFactory;
use User\Service\Factory\UserNavigationFactory;
use User\Service\UserManager;
use Zend\Authentication\AuthenticationService;
use Zend\Router\Http\Literal;
use Zend\Router\Http\Segment;

return [
    'router' => [
        'routes' => [
            'reset-password' => [
                'type' => Literal::class,
                'options' => [
                    'route'    => '/reset-password',
                    'defaults' => [
                        'controller' => Controller\UserController::class,
                        'action'     => 'reset-password',
                    ],
                ],
            ],
            'login' => [
                'type' => Literal::class,
                'options' => [
                    'route'    => '/login',
                    'defaults' => [
                        'controller' => Controller\AuthController::class,
                        'action'     => 'login',
                    ],
                ],
            ],
            'logout' => [
                'type' => Literal::class,
                'options' => [
                    'route'    => '/logout',
                    'defaults' => [
                        'controller' => Controller\AuthController::class,
                        'action'     => 'logout',
                    ],
                ],
            ],
            'user' => [
                'type' => Literal::class,
                'options' => [
                    'route' => '/user',
                    'defaults' => [
                        'controller' => Controller\UserController::class,
                        'action' => 'index',
                    ],
                ],
                'may_terminate' => true,
                'child_routes' => [
                    'view' => [
                        'type' => Literal::class,
                        'options' => [
                            'route'    => '/view',
                            'defaults' => [
                                'controller' => Controller\UserController::class,
                                'action'     => 'index',
                            ],
                        ],
                    ],
                    'set-password' => [
                        'type' => Literal::class,
                        'options' => [
                            'route'    => '/set-password',
                            'defaults' => [
                                'controller' => Controller\UserController::class,
                                'action'     => 'set-password',
                            ],
                        ],
                    ],
                ],
            ],
            'admin' => [
                'child_routes' => [
                    'user-admin' => [
                        'type' => Segment::class,
                        'options' => [
                            'route' => '/users[/page/:page][/:action[/:id]]',
                            'constraints' => [
                                'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                                'id' => '[a-z0-9][a-z0-9-]*',
                                'page' => '\d+',
                            ],
                            'defaults' => [
                                'controller'    => Controller\UserAdminController::class,
                                'action'        => 'index',
                                'page'          => 1,
                            ],
                        ],
                    ],
                ],
            ],
        ],
    ],
    'controllers' => [
        'factories' => [
            AuthController::class       => Controller\Factory\AuthControllerFactory::class,
            UserAdminController::class  => Controller\Factory\UserAdminControllerFactory::class,
            UserController::class       => Controller\Factory\UserControllerFactory::class,
        ],
    ],
    'service_manager' => [
        'aliases' => [
            AuthenticationService::class => 'doctrine.authenticationservice.orm_default',
        ],
        'factories' => [
            AuthenticationManagerFactory::class => AuthenticationManager::class,
            UserManager::class                  => UserManagerFactory::class,
            UserNavigationFactory::class        => UserNavigationFactory::class,
        ],
    ],
    'navigation' => [
        'default' => [
            'admin' => [
                'pages' => [
                    'user-admin' => [
                        'label' => 'Users',
                        'route' => 'admin/user-admin',
                        'action' => 'index',

                    ],
                ],
            ],
        ],
        'admin' => [
            'admin' => [
                'pages' => [
                    'user-admin' => [
                        'label' => 'Users',
                        'route' => 'admin/user-admin',
                        'pages' => [
                            'add-user-admin' => [
                                'label' => 'New User',
                                'route' => 'admin/user-admin',
                                'action' => 'add',
                            ],
                            'edit-user-admin' => [
                                'label' => 'Edit User',
                                'route' => 'admin/user-admin',
                                'action' => 'edit',
                            ],
                        ],
                    ],
                ],
            ],
        ],
        'dashboard' => [
            'user-admin' => [
                'label' => 'Manage Users',
                'route' => 'admin/user-admin',
                'pages' => [
                    'list-user-admin' => [
                        'label' => 'List Users',
                        'route' => 'admin/user-admin',
                        'action' => 'index',
                    ],
                    'add-user-admin' => [
                        'label' => 'New User',
                        'route' => 'admin/user-admin',
                        'action' => 'add',
                    ],
                ],
            ],
        ],
        'user' => [
            'user-setiings' => [
                'label' => 'Settings',
                'route' => 'user',
                'pages' => [
                    'view-profile' => [
                        'label' => 'Profile',
                        'route' => 'user/view',
                    ],
                    'set-password' => [
                        'label' => 'Change Password',
                        'route' => 'user/set-password',
                    ],
                ],
            ],
        ],
    ],
    'view_manager' => [
        'template_path_stack' => [
            __DIR__ . '/../view',
        ],
    ],
    // Doctrine config
    'doctrine' => [
        'authentication' => [
            'orm_default' => [
                'object_manager'        => EntityManager::class,
                'identity_class'        => UserEntity::class,
                'identity_property'     => 'email',
                'credential_property'   => 'password',
                'credential_callable'   => 'User\Service\UserManager::verifyCredential',
            ],
        ],
        'driver' => [
            __NAMESPACE__ . '_driver' => [
                'class' => AnnotationDriver::class,
                'cache' => 'array',
                'paths' => [__DIR__ . '/../src/Entity'],
            ],
            'orm_default' => [
                'drivers' => [
                    __NAMESPACE__ . '\Entity' => __NAMESPACE__ . '_driver',
                ],
            ],
        ],
    ],
];

