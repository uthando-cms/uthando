<?php
/**
 * Uthando CMS (http://www.shaunfreeman.co.uk/)
 *
 * @package   CoreTest\Entity
 * @author    Shaun Freeman <shaun@shaunfreeman.co.uk>
 * @copyright Copyright (c) 2018 Shaun Freeman. (http://www.shaunfreeman.co.uk)
 * @license   see LICENSE
 */

namespace CoreTest\Entity;

use Core\Entity\AbstractEntity;
use CoreTest\assets\AbstractEntityDummy;
use PHPUnit\Framework\TestCase;
use Ramsey\Uuid\Uuid;

class AbstractEntityTest extends TestCase
{
    public function test__get()
    {
        $mock = new AbstractEntityDummy();

        $this->assertInstanceOf(Uuid::class, $mock->id);

    }

    /**
     * @expectedException \Exception
     */
    public function testInvalid__get()
    {
        $mock = new AbstractEntityDummy();

        $value = $mock->sameUnsetProperty;

    }

    public function testGetArrayCopy()
    {
        $mock = new AbstractEntityDummy();

        $this->assertInternalType('array', $mock->getArrayCopy());
    }

    public function test__call()
    {
        $mock = new AbstractEntityDummy();

        $this->assertInstanceOf(Uuid::class, $mock->getId());

    }

    public function test__toString()
    {
        $mock = new AbstractEntityDummy();

        $this->assertInternalType('string', (string) $mock);
    }
}
